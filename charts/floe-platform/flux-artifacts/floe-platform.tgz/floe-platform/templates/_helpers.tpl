{{/*
floe-platform Helm Chart Helper Templates
=========================================

This file contains helper templates used across all chart templates.
Templates follow Helm best practices for naming, labels, and selectors.

Usage:
  {{ include "floe-platform.fullname" . }}
  {{ include "floe-platform.labels" . }}
*/}}

{{/*
Expand the name of the chart.
*/}}
{{- define "floe-platform.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this.
If release name contains chart name it will be used as a full name.
*/}}
{{- define "floe-platform.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "floe-platform.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels for all resources.
*/}}
{{- define "floe-platform.labels" -}}
helm.sh/chart: {{ include "floe-platform.chart" . }}
{{ include "floe-platform.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: floe-platform
floe.dev/environment: {{ .Values.global.environment | default "dev" }}
{{- with .Values.global.commonLabels }}
{{ toYaml . }}
{{- end }}
{{- end }}

{{/*
Immutable labels for resources with immutable label fields (e.g. volumeClaimTemplates).
Excludes helm.sh/chart and app.kubernetes.io/version which change on every chart upgrade.
See: helm/charts#7803 (Bitnami StatefulSet upgrade footgun).

WARNING: global.commonLabels are included here for label-policy compatibility.
If you change a commonLabel value after initial install, you MUST enable
postgresql.preUpgradeCleanup.enabled=true so the pre-upgrade hook can
delete and recreate the StatefulSet. Without the hook, K8s will reject
the update with an immutable field error.
*/}}
{{- define "floe-platform.immutableLabels" -}}
{{ include "floe-platform.selectorLabels" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: floe-platform
floe.dev/environment: {{ .Values.global.environment | default "dev" }}
{{- with .Values.global.commonLabels }}
{{ toYaml . }}
{{- end }}
{{- end }}

{{/*
Selector labels for pod selection.
*/}}
{{- define "floe-platform.selectorLabels" -}}
app.kubernetes.io/name: {{ include "floe-platform.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Component-specific labels.
Usage: {{ include "floe-platform.componentLabels" (dict "component" "polaris" "context" .) }}
*/}}
{{- define "floe-platform.componentLabels" -}}
{{ include "floe-platform.labels" .context }}
app.kubernetes.io/component: {{ .component }}
{{- end }}

{{/*
Component-specific selector labels.
Usage: {{ include "floe-platform.componentSelectorLabels" (dict "component" "polaris" "context" .) }}
*/}}
{{- define "floe-platform.componentSelectorLabels" -}}
{{ include "floe-platform.selectorLabels" .context }}
app.kubernetes.io/component: {{ .component }}
{{- end }}

{{/*
Create the name of the service account to use.
*/}}
{{- define "floe-platform.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "floe-platform.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Namespace helper - returns the namespace to deploy to.
Uses release namespace unless explicitly overridden.
*/}}
{{- define "floe-platform.namespace" -}}
{{- if .Values.namespace.name }}
{{- .Values.namespace.name }}
{{- else }}
{{- .Release.Namespace }}
{{- end }}
{{- end }}

{{/*
Environment-based namespace using cluster mapping.
Usage: {{ include "floe-platform.environmentNamespace" (dict "environment" "staging" "context" .) }}
*/}}
{{- define "floe-platform.environmentNamespace" -}}
{{- $env := .environment }}
{{- $context := .context }}
{{- $mapping := dict }}
{{- range $key, $value := $context.Values.clusterMapping }}
{{- if has $env $value.environments }}
{{- $mapping = $value }}
{{- end }}
{{- end }}
{{- if $mapping.namespaceTemplate }}
{{- tpl $mapping.namespaceTemplate (dict "environment" $env) }}
{{- else }}
{{- printf "floe-%s" $env }}
{{- end }}
{{- end }}

{{/*
PostgreSQL connection string.
Returns the connection string for PostgreSQL based on configuration.
*/}}
{{- define "floe-platform.postgresql.host" -}}
{{- if .Values.postgresql.enabled }}
{{- printf "%s-postgresql" (include "floe-platform.fullname" .) }}
{{- else }}
{{- .Values.dagster.postgresql.host }}
{{- end }}
{{- end }}

{{- define "floe-platform.postgresql.port" -}}
{{- if .Values.postgresql.enabled }}
{{- 5432 }}
{{- else }}
{{- .Values.dagster.postgresql.port | default 5432 }}
{{- end }}
{{- end }}

{{/*
PostgreSQL secret name.
*/}}
{{- define "floe-platform.postgresql.secretName" -}}
{{- if .Values.postgresql.auth.existingSecret }}
{{- .Values.postgresql.auth.existingSecret }}
{{- else }}
{{- printf "%s-postgresql" (include "floe-platform.fullname" .) }}
{{- end }}
{{- end }}

{{/*
Polaris component name.
*/}}
{{- define "floe-platform.polaris.fullname" -}}
{{- printf "%s-polaris" (include "floe-platform.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
OTel Collector component name.
*/}}
{{- define "floe-platform.otel.fullname" -}}
{{- if .Values.otel.fullnameOverride }}
{{- .Values.otel.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-otel" (include "floe-platform.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{/*
Loki component name.
*/}}
{{- define "floe-platform.loki.fullname" -}}
{{- if .Values.loki.fullnameOverride }}
{{- .Values.loki.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-loki" (include "floe-platform.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{/*
Prometheus component name.
*/}}
{{- define "floe-platform.prometheus.fullname" -}}
{{- if .Values.prometheus.fullnameOverride }}
{{- .Values.prometheus.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-prometheus" (include "floe-platform.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{/*
Find an environment variable value in a list of env var maps.
*/}}
{{- define "floe-platform.envValue" -}}
{{- $name := .name -}}
{{- $value := "" -}}
{{- range .env }}
{{- if eq .name $name }}
{{- $value = (.value | default "") }}
{{- end }}
{{- end }}
{{- $value }}
{{- end }}

{{/*
Validate that static Dagster OTLP endpoint env vars match the rendered OTel service.
The Dagster subchart renders env values with toYaml, so these cannot be templated.
*/}}
{{- define "floe-platform.validateDagsterOtelEndpoint" -}}
{{- $context := .context -}}
{{- $component := .component -}}
{{- $env := .env | default list -}}
{{- $expected := printf "http://%s:4317" (include "floe-platform.otel.fullname" $context) -}}
{{- $actual := include "floe-platform.envValue" (dict "env" $env "name" "OTEL_EXPORTER_OTLP_ENDPOINT") -}}
{{- if and (default false $context.Values.otel.enabled) (default false $context.Values.dagster.enabled) (ne $actual $expected) }}
{{- fail (printf "Dagster %s OTEL_EXPORTER_OTLP_ENDPOINT must be %q to match OTel service %q; got %q. If otel.fullnameOverride is set, override both dagster.dagsterWebserver.env and dagster.dagsterDaemon.env to the matching endpoint." $component $expected (include "floe-platform.otel.fullname" $context) $actual) }}
{{- end }}
{{- end }}

{{/*
Validate all Dagster OTLP endpoints that are enabled for the platform chart.
*/}}
{{- define "floe-platform.validateDagsterOtelEndpoints" -}}
{{- include "floe-platform.validateDagsterOtelEndpoint" (dict "context" . "component" "dagsterWebserver" "env" .Values.dagster.dagsterWebserver.env) }}
{{- if default false .Values.dagster.dagsterDaemon.enabled }}
{{- include "floe-platform.validateDagsterOtelEndpoint" (dict "context" . "component" "dagsterDaemon" "env" .Values.dagster.dagsterDaemon.env) }}
{{- end }}
{{- end }}

{{/*
Jaeger query service name.
Jaeger subchart uses Release.Name as its prefix (not fullnameOverride),
so service names follow the pattern: {Release.Name}-jaeger-query.
*/}}
{{- define "floe-platform.jaeger.queryName" -}}
{{- printf "%s-jaeger-query" .Release.Name | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Marquez component name.
*/}}
{{- define "floe-platform.marquez.fullname" -}}
{{- printf "%s-marquez" (include "floe-platform.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Dagster webserver service name.
The upstream Dagster subchart prefixes resources with .Release.Name, not the
parent chart fullnameOverride.
*/}}
{{- define "floe-platform.dagster.webserverName" -}}
{{- printf "%s-dagster-webserver" .Release.Name | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Dagster webserver service port.
Kept behind a helper so tests, notes, and ingress stay aligned with the
upstream Dagster subchart values selected by the active values stack.
*/}}
{{- define "floe-platform.dagster.webserverPort" -}}
{{- required "dagster.dagsterWebserver.service.port is required" .Values.dagster.dagsterWebserver.service.port }}
{{- end }}

{{/*
MinIO component name.
*/}}
{{- define "floe-platform.minio.fullname" -}}
{{- printf "%s-minio" (include "floe-platform.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
MinIO secret name (used for root-user/root-password keys).
*/}}
{{- define "floe-platform.minio.secretName" -}}
{{- if .Values.minio.auth.existingSecret }}
{{- .Values.minio.auth.existingSecret }}
{{- else }}
{{- include "floe-platform.minio.fullname" . }}
{{- end }}
{{- end }}

{{/*
Polaris credentials secret name.
Single source of truth for the Secret holding client-id, client-secret,
POLARIS_CREDENTIAL, aws-access-key-id, and aws-secret-access-key. Used
by the polaris bootstrap Job and every test Job. Do NOT inline the
`%s-credentials` printf expression elsewhere — call this helper.
*/}}
{{- define "floe-platform.polaris.credentialSecretName" -}}
{{- if .Values.polaris.auth.existingSecret }}
{{- .Values.polaris.auth.existingSecret }}
{{- else }}
{{- printf "%s-credentials" (include "floe-platform.polaris.fullname" .) }}
{{- end }}
{{- end }}

{{/*
Polaris S3 credential secret name.
Storage credentials are a separate concern from Polaris OAuth credentials. When
the operator does not provide an explicit S3 credential secret, local MinIO
deployments reuse the MinIO root credential secret. External S3-compatible
deployments must provide a Kubernetes Secret reference generated by platform
composition.
*/}}
{{- define "floe-platform.polaris.s3CredentialSecretName" -}}
{{- if .Values.polaris.storage.s3.credentialSecretName }}
{{- .Values.polaris.storage.s3.credentialSecretName }}
{{- else if .Values.minio.enabled }}
{{- include "floe-platform.minio.secretName" . }}
{{- else }}
{{- fail "polaris.storage.s3.credentialSecretName is required when polaris.storage.s3.enabled=true and minio.enabled=false" }}
{{- end }}
{{- end }}

{{/*
Key containing the S3 access key inside the selected S3 credential secret.
*/}}
{{- define "floe-platform.polaris.s3AccessKeySecretKey" -}}
{{- if .Values.polaris.storage.s3.accessKeySecretKey }}
{{- .Values.polaris.storage.s3.accessKeySecretKey }}
{{- else if .Values.minio.enabled }}
{{- "root-user" }}
{{- else }}
{{- "aws-access-key-id" }}
{{- end }}
{{- end }}

{{/*
Key containing the S3 secret key inside the selected S3 credential secret.
*/}}
{{- define "floe-platform.polaris.s3SecretKeySecretKey" -}}
{{- if .Values.polaris.storage.s3.secretKeySecretKey }}
{{- .Values.polaris.storage.s3.secretKeySecretKey }}
{{- else if .Values.minio.enabled }}
{{- "root-password" }}
{{- else }}
{{- "aws-secret-access-key" }}
{{- end }}
{{- end }}

{{/*
Standard (non-destructive) test runner ServiceAccount name.
Used by test Jobs in templates/tests/ for e2e and integration test suites.
*/}}
{{- define "floe-platform.testRunner.saName" -}}
{{- printf "%s-test-runner" (include "floe-platform.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Destructive test runner ServiceAccount name.
Used by test Jobs that mutate platform state (helm upgrade, pod delete).
Has elevated RBAC compared to the standard runner.
*/}}
{{- define "floe-platform.testRunnerDestructive.saName" -}}
{{- printf "%s-test-runner-destructive" (include "floe-platform.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Canonical Polaris warehouse/catalog name.
Single source of truth for the warehouse identifier used by both the
Polaris bootstrap Job (as catalog name) and test Jobs (as POLARIS_WAREHOUSE).
Reads .Values.polaris.bootstrap.catalogName — do NOT duplicate this elsewhere.
*/}}
{{- define "floe-platform.polaris.warehouse" -}}
{{- required "polaris.bootstrap.catalogName is required — set .Values.polaris.bootstrap.catalogName" .Values.polaris.bootstrap.catalogName }}
{{- end }}

{{/*
Common annotations for all resources.
*/}}
{{- define "floe-platform.annotations" -}}
{{- with .Values.global.commonAnnotations }}
{{ toYaml . }}
{{- end }}
{{- end }}

{{/*
Pod security context.
*/}}
{{- define "floe-platform.podSecurityContext" -}}
{{- toYaml .Values.podSecurityContext }}
{{- end }}

{{/*
Container security context.
*/}}
{{- define "floe-platform.containerSecurityContext" -}}
{{- toYaml .Values.containerSecurityContext }}
{{- end }}

{{/*
Image pull secrets.
*/}}
{{- define "floe-platform.imagePullSecrets" -}}
{{- with .Values.global.imagePullSecrets }}
imagePullSecrets:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- end }}

{{/*
Resource preset lookup.
Usage: {{ include "floe-platform.resourcePreset" (dict "preset" "small" "context" .) }}
*/}}
{{- define "floe-platform.resourcePreset" -}}
{{- $preset := .preset }}
{{- $presets := .context.Values.resourcePresets }}
{{- if hasKey $presets $preset }}
{{- toYaml (get $presets $preset) }}
{{- else }}
{{- toYaml (get $presets "small") }}
{{- end }}
{{- end }}

{{/*
Wait-for-postgres init container.
Waits for PostgreSQL to be ready before starting main container.
*/}}
{{- define "floe-platform.waitForPostgres" -}}
- name: wait-for-postgres
  image: postgres:16-alpine
  imagePullPolicy: {{ .Values.global.imagePullPolicy }}
  env:
    - name: JDBC_URL
      value: {{ .Values.polaris.persistence.jdbc.url | quote }}
  command:
    - /bin/sh
    - -c
    - |
      set -eu

      CONNECTION_TARGET="${JDBC_URL#jdbc:postgresql://}"
      if [ "${CONNECTION_TARGET}" = "${JDBC_URL}" ]; then
        echo "ERROR: Unsupported PostgreSQL JDBC URL: ${JDBC_URL}" >&2
        exit 1
      fi

      AUTHORITY="${CONNECTION_TARGET%%/*}"
      if [ -z "${AUTHORITY}" ]; then
        echo "ERROR: Unable to parse PostgreSQL host from JDBC URL: ${JDBC_URL}" >&2
        exit 1
      fi

      case "${AUTHORITY}" in
        \[*\]:*)
          PGHOST_PARSED="${AUTHORITY%\]:*}"
          PGHOST_PARSED="${PGHOST_PARSED#\[}"
          PGPORT_PARSED="${AUTHORITY##*\]:}"
          ;;
        *:*)
          PGHOST_PARSED="${AUTHORITY%:*}"
          PGPORT_PARSED="${AUTHORITY##*:}"
          ;;
        *)
          PGHOST_PARSED="${AUTHORITY}"
          PGPORT_PARSED="5432"
          ;;
      esac

      until pg_isready -h "${PGHOST_PARSED}" -p "${PGPORT_PARSED}"; do
        echo "Waiting for PostgreSQL..."
        sleep 2
      done
      echo "PostgreSQL is ready"
  securityContext:
    allowPrivilegeEscalation: false
    readOnlyRootFilesystem: true
    runAsNonRoot: true
    runAsUser: 70
    runAsGroup: 70
    capabilities:
      drop:
        - ALL
{{- end }}
